import vector.Vector2;

public class ProvisionalMain {
    public static void main(String[] args) {
        Vector2 vector1 = new Vector2(1, 3);
        Vector2 vector2 = new Vector2(4, 6);

        // Vector module
        System.out.println(vector1.module());

        // Vectors sum
        Vector2 vectorSum = new Vector2();
        vectorSum = vector1.sum(vector2);

        System.out.println("Vectors sum");
        System.out.println(vectorSum.getX());
        System.out.println(vectorSum.getY());
        System.out.println("---------");

        // Number multiplication
        Vector2 vectorScMu = new Vector2();
        vectorScMu = vector2.numMult(2);

        System.out.println("Scalar multiplication");
        System.out.println(vectorScMu.getX());
        System.out.println(vectorScMu.getY());
        System.out.println("---------");

        // Deny a vector
        Vector2 denVector = new Vector2();
        denVector = vector2.deny();

        System.out.println("Deny a vector");
        System.out.println(denVector.getX());
        System.out.println(denVector.getY());
        System.out.println("---------");

        // Scalar product
        Vector2 scalarProductVector = new Vector2();
        scalarProductVector = vector1.scalarProduct(vector2);

        System.out.println("Scalar product");
        System.out.println(scalarProductVector.getX());
        System.out.println(scalarProductVector.getY());
        System.out.println("---------");



    }
}
